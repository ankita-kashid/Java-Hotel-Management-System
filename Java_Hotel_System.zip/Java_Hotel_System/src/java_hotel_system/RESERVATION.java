/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_hotel_system;

import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.date;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lenovo
 */
public class RESERVATION {
    //alter TABLE reservations ADD CONSTRAINT fk_room_number FOREIGN KEY (room_number) REFERENCES clients(id) ON DELETE CASCADE
    
    MY_CONNECTION my_connection = new MY_CONNECTION();
    public boolean addReservation(int client_id,int room_number,Date date_in,Date date_out) {
        PreparedStatement st;
        ResultSet rs;
        String addQuery = "INSERT INTO `reservations`(`client_id`, `room_number`, `date_in`, `date_out`) VALUES (?,?,?,?)";

        try {

            st = my_connection.createConnection().prepareStatement(addQuery);

            st.setInt(1, client_id);
            st.setInt(2, room_number);
            st.setDate(3, date_in);
            st.setDate(4, date_out);
         
         

            if (st.executeUpdate() > 0) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException ex) {
            Logger.getLogger(CLIENT.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }
    public boolean editReservation(int reservation_id,int client_id,int room_number,DateFormat date_in,DateFormat date_out) {
        PreparedStatement st;
        ResultSet rs;
        String editQuery = "UPDATE `reservations` SET `client_id`=?,`room_number`=?,`date_in`=?,`date_out`=? WHERE `id`=?";

        try {

            st = my_connection.createConnection().prepareStatement(editQuery);

            st.setInt(1, reservation_id);
            st.setInt(2, client_id);
            st.setInt(3, room_number);
            st.setDate(4, date_in);
            st.setDate(5, date_out);
            
            

            return (st.executeUpdate() > 0);

        } catch (SQLException ex) {
            Logger.getLogger(CLIENT.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }
    public boolean removeReservation(int reservation_id) {
        PreparedStatement st;
        ResultSet rs;
        String deleteQuery = "DELETE FROM `reservations` WHERE `id`=?";

        try {

            st = my_connection.createConnection().prepareStatement(deleteQuery);

            st.setInt(1, reservation_id);

            return (st.executeUpdate() > 0);

        } catch (SQLException ex) {
            Logger.getLogger(CLIENT.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }

    
   

    
}
